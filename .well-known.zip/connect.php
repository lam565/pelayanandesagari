<?php
$dbHost="localhost";
$dbUser="arss3997_pelayanan";
$dbPass="gari2020!@#";
$dbName="arss3997_pelayanan";

$connect=mysqli_connect ($dbHost, $dbUser, $dbPass, $dbName);
if (!$connect) die("koneksi gagal : ". mysqli_connect_error());
?>