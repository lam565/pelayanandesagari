<?php
include "connect.php";
session_start();

$nik=$_POST['NIK'];
$tanggal=date('Y-m-d');
$no_surat=$_POST['no_surat'];
$username=$_POST['username'];
$staf=$_POST['staf'];
$keperluan=$_POST['keperluan'];

$sql="insert into pengantar values('$no_surat','$nik','$tanggal','$keperluan','$staf','$username','1')";
$results=mysqli_query($connect,$sql)or die("error:".mysqli_error($connect));
if ($results) {
    echo "<script>alert('Data Berhasil Disimpan'); window.location = 'tb_surat.php?err=0.php'</script>";
} else {
    echo "Terjadi Kesalahan Silahkan tekan Kembali";
}
?>